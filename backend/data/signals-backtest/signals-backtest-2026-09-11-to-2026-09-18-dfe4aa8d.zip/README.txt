Signal backtest -- what is in this zip
=========================================

Every file is a plain CSV (open in Excel). Times are IST. "bps" is basis points: 1 bps = 0.01%.

run.json
    The run: period, dates, when it ran, the app and mechanism versions, every parameter of every
    series, how many ICICI calls the fetch spent, and notes (data gaps, days without bars).

summary.csv
    One row per index x mechanism x duration -- the headline numbers:
    sessions_replayed      trading sessions that had bars to replay
    calls                  how many calls (bullish or bearish) the signal made
    right / wrong          calls where the index moved the called way / the other way by at least
                           the breakeven move within the duration; smaller moves are neither
    hit_rate               right / (right + wrong)
    <side>_trend_share     how often the index moved that way after ANY reading -- the bar a
                           side's hit rate must beat to mean anything
    <side>_verdict         better / worse / no_edge than the trend share (95% range, calls at
                           least one duration apart), or too_few_calls (under 30 separate calls)
    verdict                edge (both sides better), worse (a side reliably worse), no_edge,
                           or too_few_calls
    mean_move_*_bps        average index move the called way after the call
    breakeven_bps          the move one lot of the at-the-money option needs to pay its round-trip
                           charges (Settings -> Trading Costs), in bps of the index
    rough_pnl_one_lot_rupees  ROUGH: called-way index points x lot x delta 0.5, less charges,
                           summed over calls. No spread, no time decay -- the bot backtests price
                           real options; this is only for comparing signals with each other.
    mean_daily_correlation strength vs the next move, correlated per day then averaged (pooling
                           days manufactures correlation)

<INDEX>/bars.csv
    The exact one-minute futures bars the run replayed (NIFTY near-month on NFO, SENSEX BSESEN on
    BFO), including pre-open bars, which feed the session VWAP only. Anything in this zip can be
    recomputed from these.

<INDEX>/<mechanism>-<duration>/readings.csv
    One row per minute of the session: the bar, the reading (state, reason, strength), the call it
    belonged to, every input the mechanism computed (c_* columns), and where the index was 1, 5,
    15 and 30 minutes later (fwd_*_bps).

<INDEX>/<mechanism>-<duration>/calls.csv
    One row per call: when it fired, which way, at what level, everything the mechanism read when
    it fired (c_*), how it ended (lapsed / turned / unavailable / session_end), the move after one
    and two durations and at its end, the best and worst move while it stood, and the result.

<INDEX>/<mechanism>-<duration>/days.csv
    One row per session: the day's move, readings, calls, hit rate, the day's correlation, and
    whether it was a rollover day (NIFTY expansion reads no OI then, so it stands down).

States: bullish / bearish are calls; neutral means the market was read and nothing fired;
unavailable means there was no reading (warming up, outside the session, a data gap), and is never
a quiet market.

SENSEX runs on BSESEN futures, which trade thinly (no trade in about half the minutes), and ICICI
serves no BSE open interest, so SENSEX expansion reads price and volume only.
